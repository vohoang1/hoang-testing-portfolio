package testcsv;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import com.opencsv.CSVReader;
public class CSVReader2 {
	public static void main(String[] args) {
        String path = "D:\\test.csv";
        try (Reader reader = new FileReader(path);
             CSVReader csvreader = new CSVReader(reader)) {
            List<String[]> list = csvreader.readAll();
            Iterator<String[]> ite = list.iterator();
            while (ite.hasNext()) {
                String[] data = ite.next();
                if (data.length >= 3) {
                    System.out.println("TestID:" + data[0]);
                    System.out.println("Địa chỉ:" + data[1]);
                    System.out.println("Kịch bản:" + data[2]);
                    System.out.println("Mô tả: " + data[3]);
                }
                System.out.println("........");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
