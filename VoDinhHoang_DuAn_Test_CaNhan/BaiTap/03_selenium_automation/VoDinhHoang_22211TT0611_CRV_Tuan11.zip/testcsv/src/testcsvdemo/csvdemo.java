package testcsvdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;

public class csvdemo {
    public static void main(String[] args) {
        // Thiết lập đường dẫn tới ChromeDriver
    	System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        
        // Khởi tạo WebDriver
        WebDriver driver = new ChromeDriver();
        
        // Mở trang web
        driver.get("https://demoqa.com/text-box");

        String path = "D:\\csvtest.csv";
        try (Reader reader = new FileReader(path);
             CSVReader csvreader = new CSVReader(reader)) {
            List<String[]> list = csvreader.readAll();
            Iterator<String[]> ite = list.iterator();
            
            // Đọc dữ liệu từ CSV và nhập vào trang web
            while (ite.hasNext()) {
                String[] data = ite.next();
                if (data.length >= 4) {
                    // Nhập dữ liệu vào các trường tương ứng trên trang web
                    WebElement fullNameField = driver.findElement(By.id("userName"));
                    fullNameField.sendKeys(data[0]);

                    WebElement emailField = driver.findElement(By.id("userEmail"));
                    emailField.sendKeys(data[1]);

                    WebElement currentAddressField = driver.findElement(By.id("currentAddress"));
                    currentAddressField.sendKeys(data[2]);

                    WebElement permanentAddressField = driver.findElement(By.id("permanentAddress"));
                    permanentAddressField.sendKeys(data[3]);

                    // Click vào nút Submit (nếu có) để gửi dữ liệu
                    WebElement submitButton = driver.findElement(By.id("submit"));
                    submitButton.click();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Đóng trình duyệt
            driver.quit();
        }
    }
}
